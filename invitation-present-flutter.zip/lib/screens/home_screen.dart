import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _formKey = GlobalKey<FormState>();
  final _serialController = TextEditingController();
  final _nameController = TextEditingController();
  final _addressController = TextEditingController();
  final _amountController = TextEditingController();
  List records = [];

  @override
  void initState() {
    super.initState();
    fetchRecords();
  }

  Future<void> fetchRecords() async {
    final response = await http.get(Uri.parse('http://localhost:8080/api/records'));
    if (response.statusCode == 200) {
      setState(() {
        records = json.decode(response.body);
      });
    }
  }

  Future<void> submitRecord() async {
    if (!_formKey.currentState!.validate()) return;

    final response = await http.post(
      Uri.parse('http://localhost:8080/api/records'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'serialNumber': int.parse(_serialController.text),
        'name': _nameController.text,
        'address': _addressController.text,
        'amount': double.parse(_amountController.text),
      }),
    );

    if (response.statusCode == 200) {
      fetchRecords();
      _serialController.clear();
      _nameController.clear();
      _addressController.clear();
      _amountController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Invitation Record')),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _serialController,
                    decoration: const InputDecoration(labelText: 'Serial Number'),
                    keyboardType: TextInputType.number,
                    validator: (value) => value!.isEmpty ? 'Enter serial number' : null,
                  ),
                  TextFormField(
                    controller: _nameController,
                    decoration: const InputDecoration(labelText: 'Name'),
                    validator: (value) => value!.isEmpty ? 'Enter name' : null,
                  ),
                  TextFormField(
                    controller: _addressController,
                    decoration: const InputDecoration(labelText: 'Address'),
                    validator: (value) => value!.isEmpty ? 'Enter address' : null,
                  ),
                  TextFormField(
                    controller: _amountController,
                    decoration: const InputDecoration(labelText: 'Amount'),
                    keyboardType: TextInputType.number,
                    validator: (value) => value!.isEmpty ? 'Enter amount' : null,
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton(onPressed: submitRecord, child: const Text('Submit')),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Text('Saved Records:', style: TextStyle(fontWeight: FontWeight.bold)),
            Expanded(
              child: ListView.builder(
                itemCount: records.length,
                itemBuilder: (context, index) {
                  final record = records[index];
                  return Card(
                    child: ListTile(
                      title: Text(record['name']),
                      subtitle: Text('${record['address']} | Amount: ${record['amount']}'),
                      leading: Text(record['serialNumber'].toString()),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}