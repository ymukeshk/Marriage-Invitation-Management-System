package com.example.invitation;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface InvitationRecordRepository extends JpaRepository<InvitationRecord, Long> {

}