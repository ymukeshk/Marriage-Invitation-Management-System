package com.example.invitation;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "GudiyaMarriageTable")
public class InvitationRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String address;
    private BigDecimal amount;

    @Column(nullable = true)
    private String saree;

    @Column(nullable = true)
    private String others;

    @Column(name = "recorded_at")
    private LocalDateTime recordedAt;

    // Auto-set the recordedAt value before insert
    @PrePersist
    public void prePersist() {
        this.recordedAt = LocalDateTime.now(); // Will store current date/time (in system timezone)
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getSaree() {
        return saree;
    }

    public void setSaree(String saree) {
        this.saree = saree;
    }

    public String getOthers() {
        return others;
    }

    public void setOthers(String others) {
        this.others = others;
    }

    public LocalDateTime getRecordedAt() {
        return recordedAt;
    }

    public void setRecordedAt(LocalDateTime recordedAt) {
        this.recordedAt = recordedAt;
    }
}
