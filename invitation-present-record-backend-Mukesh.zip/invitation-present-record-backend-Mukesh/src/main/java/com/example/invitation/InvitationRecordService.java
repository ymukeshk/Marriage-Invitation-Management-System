package com.example.invitation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class InvitationRecordService {
    @Autowired
    private InvitationRecordRepository repository;

    public List<InvitationRecord> getAll() {
        return repository.findAll();
    }
    // ✅ Get record by ID
    public InvitationRecord getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Record not found with ID: " + id));
    }



    // ✅ Optional: Clean update logic (used by controller)
    public InvitationRecord updateById(Long id, InvitationRecord updatedRecord) {
        InvitationRecord existing = getById(id); // throws if not found
        existing.setName(updatedRecord.getName());
        existing.setAddress(updatedRecord.getAddress());
        existing.setAmount(updatedRecord.getAmount());
        existing.setSaree(updatedRecord.getSaree());
        existing.setOthers(updatedRecord.getOthers());
        return repository.save(existing);
    }
    public BigDecimal getTotalAmount() {
        return repository.findAll().stream()
                .map(r -> r.getAmount() != null ? r.getAmount() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public InvitationRecord save(InvitationRecord record) {
        return repository.save(record);
    }
}