package com.example.invitation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InvitationRecordApp {
    public static void main(String[] args) {
        SpringApplication.run(InvitationRecordApp.class, args);
    }
}