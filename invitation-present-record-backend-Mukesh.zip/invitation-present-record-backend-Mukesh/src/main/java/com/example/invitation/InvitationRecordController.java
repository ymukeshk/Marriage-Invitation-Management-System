package com.example.invitation;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.List;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/records")
public class InvitationRecordController {

    @Autowired
    private InvitationRecordService service;
    @Autowired
    private InvitationRecordRepository repository;

    @PostMapping
    public InvitationRecord save(@RequestBody InvitationRecord record) {
        return service.save(record);
    }

    @GetMapping
    public List<InvitationRecord> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public InvitationRecord updateRecord(@PathVariable Long id, @RequestBody InvitationRecord updatedRecord) {
        InvitationRecord existing = service.getById(id);
        if (existing != null) {
            existing.setName(updatedRecord.getName());
            existing.setAddress(updatedRecord.getAddress());
            existing.setAmount(updatedRecord.getAmount());
            existing.setSaree(updatedRecord.getSaree());
            return service.save(existing);
        } else {
            throw new RuntimeException("Record not found with ID: " + id);
        }
    }
    @GetMapping("/total-amount")
    public BigDecimal getTotalAmount() {
        return service.getTotalAmount();
    }

    @GetMapping("/export/pdf")
    public void exportToPdf(HttpServletResponse response) throws Exception {
        // Setup the response
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=Gudiya_Marriage.pdf");

        // PDF document
        Document doc = new Document();
        PdfWriter.getInstance(doc, response.getOutputStream());
        doc.open();

        // Setup formatter for IST
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

        // 6 columns now including Date and Time
        PdfPTable table = new PdfPTable(6);
        table.addCell("Serial No");
        table.addCell("Name");
        table.addCell("Address");
        table.addCell("Amount");
        table.addCell("Saree");
        table.addCell("Date & Time");

        List<InvitationRecord> records = service.getAll();
        for (InvitationRecord r : records) {
            table.addCell(String.valueOf(r.getId()));
            table.addCell(r.getName());
            table.addCell(r.getAddress());
            table.addCell(r.getAmount().toString());
            table.addCell(r.getSaree() != null ? r.getSaree() : "");
            table.addCell(r.getRecordedAt() != null ? r.getRecordedAt().format(formatter) : "");
        }

        doc.add(table);
        doc.close();
    }

    @GetMapping("/export/xls")
    public void exportToExcel(HttpServletResponse response) throws IOException {
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=records.xlsx");

        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Records");
        Row header = sheet.createRow(0);
        header.createCell(0).setCellValue("Serial No");
        header.createCell(1).setCellValue("Name");
        header.createCell(2).setCellValue("Address");
        header.createCell(3).setCellValue("Amount");
        header.createCell(4).setCellValue("Saree");

        int rowIdx = 1;
        for (InvitationRecord r : service.getAll()) {
            Row row = sheet.createRow(rowIdx++);
            row.createCell(0).setCellValue(r.getId());
            row.createCell(1).setCellValue(r.getName());
            row.createCell(2).setCellValue(r.getAddress());
            row.createCell(3).setCellValue(r.getAmount().doubleValue());
            row.createCell(4).setCellValue(r.getSaree());
        }

        workbook.write(response.getOutputStream());
        workbook.close();
    }

}